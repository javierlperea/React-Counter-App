import React from 'react';
import ReactDOM from 'react-dom';
import CounterApp from './CounterApp';
import './index.css'

//Accedo al div a donde renderizo mi componento
const divRoot = document.getElementById('root')

//renderizo y comunico componentes (envio un objeto de tipo number)
ReactDOM.render( <CounterApp value={0} />, divRoot );

